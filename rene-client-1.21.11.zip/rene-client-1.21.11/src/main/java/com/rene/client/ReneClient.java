package com.rene.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

public class ReneClient implements ClientModInitializer {
    private static boolean menuOpen = false;
    private static boolean potatoMode = false;
    private static boolean shiftWasDown = false;
    private static boolean pWasDown = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client == null) return;
            Window window = client.getWindow();
            boolean shiftDown = GLFW.glfwGetKey(window.getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            boolean pDown = GLFW.glfwGetKey(window.getHandle(), GLFW.GLFW_KEY_P) == GLFW.GLFW_PRESS;
            if (shiftDown && !shiftWasDown) menuOpen = !menuOpen;
            if (pDown && !pWasDown) potatoMode = !potatoMode;
            shiftWasDown = shiftDown;
            pWasDown = pDown;
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int blue = 0xFF55AAFF;
        ctx.drawText(client.textRenderer, "RENE CLIENT", 8, 8, blue, true);
        ctx.drawText(client.textRenderer, "FPS: " + client.getCurrentFps(), 8, 20, 0xFFFFFFFF, true);
        ctx.drawText(client.textRenderer, "POTATO FPS: " + (potatoMode ? "ON" : "OFF"), 8, 32,
                potatoMode ? 0xFF66FF99 : 0xFFAAAAAA, true);
        if (menuOpen) {
            int x = 8, y = 48;
            ctx.fill(x - 3, y - 3, x + 126, y + 43, 0xCC0A1B2D);
            ctx.drawText(client.textRenderer, "RENE CLIENT MENU", x, y, blue, true);
            ctx.drawText(client.textRenderer, "P: Potato FPS " + (potatoMode ? "ON" : "OFF"), x, y + 13, 0xFFFFFFFF, true);
            ctx.drawText(client.textRenderer, "Right Shift: close", x, y + 26, 0xFFBBD8FF, true);
        }
    }
}
