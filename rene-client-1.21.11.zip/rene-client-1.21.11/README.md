# Rene Client (Minecraft 1.21.11)

Client-side Fabric starter project with a blue Rene Client HUD.


## Current starter features
- Rene Client label and FPS counter
- Right Shift toggles a simple menu overlay
- P toggles the Potato FPS status indicator

Note: the Potato FPS key currently changes a status flag only; actual texture/graphics optimizations are not implemented yet.

## Build
Requires Java 21 and Gradle (or a Gradle wrapper).

From this project folder, run:
- Windows: `gradle build`
- Linux/macOS: `gradle build`

The compiled mod JAR will be in `build/libs/` if the build succeeds.

Minecraft target: 1.21.11
Fabric Loader: 0.18.1
Fabric API: 0.141.1+1.21.11
Yarn mappings: 1.21.11+build.3
